
export type BlockType = 'text' | 'image' | 'heading' | 'divider';

export interface Block {
  id: string;
  type: BlockType;
  content: string;
  width: number; // percentage 10-100
  style?: {
    textAlign?: 'left' | 'center' | 'right';
    fontSize?: string;
  };
}

export interface Page {
  id: string;
  title: string;
  blocks: Block[];
  subPages: Page[];
  parentId: string | null;
}

export interface AppState {
  userName: string;
  pages: Page[];
  activePageId: string | null;
  isSidebarOpen: boolean;
}
