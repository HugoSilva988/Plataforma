
import React, { useState, useEffect, useCallback } from 'react';
import { 
  Plus, 
  Trash2, 
  Save, 
  Layout, 
  ChevronRight, 
  ChevronDown, 
  FileText, 
  Image as ImageIcon, 
  Type, 
  Minus, 
  Maximize2, 
  PanelLeftClose, 
  PanelLeftOpen,
  Sparkles,
  User,
  MoreVertical,
  Layers
} from 'lucide-react';
import { Page, Block, BlockType, AppState } from './types';
import { generatePageContent } from './services/geminiService';

const DEFAULT_WIDTH = 100;

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    userName: '',
    pages: [],
    activePageId: null,
    isSidebarOpen: true,
  });

  const [isNameModalOpen, setIsNameModalOpen] = useState(true);
  const [tempUserName, setTempUserName] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  // Initialize first page if user exists
  useEffect(() => {
    if (state.userName && state.pages.length === 0) {
      const firstPageId = Math.random().toString(36).substr(2, 9);
      const newPage: Page = {
        id: firstPageId,
        title: 'Home Page',
        blocks: [
          { id: '1', type: 'heading', content: `Welcome, ${state.userName}!`, width: 100 },
          { id: '2', type: 'text', content: 'Start building your platform by adding subpages or content blocks.', width: 100 }
        ],
        subPages: [],
        parentId: null
      };
      setState(prev => ({ ...prev, pages: [newPage], activePageId: firstPageId }));
    }
  }, [state.userName]);

  const handleSetUserName = () => {
    if (tempUserName.trim()) {
      setState(prev => ({ ...prev, userName: tempUserName }));
      setIsNameModalOpen(false);
    }
  };

  const createPage = (parentId: string | null = null) => {
    const newPageId = Math.random().toString(36).substr(2, 9);
    const newPage: Page = {
      id: newPageId,
      title: 'Untitled Page',
      blocks: [],
      subPages: [],
      parentId: parentId
    };

    const updatePagesRecursively = (pages: Page[]): Page[] => {
      if (!parentId) return [...pages, newPage];
      return pages.map(p => {
        if (p.id === parentId) {
          return { ...p, subPages: [...p.subPages, newPage] };
        }
        return { ...p, subPages: updatePagesRecursively(p.subPages) };
      });
    };

    setState(prev => ({
      ...prev,
      pages: updatePagesRecursively(prev.pages),
      activePageId: newPageId
    }));
  };

  const deletePage = (id: string) => {
    const filterPagesRecursively = (pages: Page[]): Page[] => {
      return pages.filter(p => p.id !== id).map(p => ({
        ...p,
        subPages: filterPagesRecursively(p.subPages)
      }));
    };

    setState(prev => {
      const newPages = filterPagesRecursively(prev.pages);
      return {
        ...prev,
        pages: newPages,
        activePageId: prev.activePageId === id ? (newPages[0]?.id || null) : prev.activePageId
      };
    });
  };

  const findPageById = (id: string, pages: Page[]): Page | null => {
    for (const p of pages) {
      if (p.id === id) return p;
      const found = findPageById(id, p.subPages);
      if (found) return found;
    }
    return null;
  };

  const updateActivePage = (updates: Partial<Page>) => {
    if (!state.activePageId) return;

    const updateRecursively = (pages: Page[]): Page[] => {
      return pages.map(p => {
        if (p.id === state.activePageId) {
          return { ...p, ...updates };
        }
        return { ...p, subPages: updateRecursively(p.subPages) };
      });
    };

    setState(prev => ({ ...prev, pages: updateRecursively(prev.pages) }));
  };

  const addBlock = (type: BlockType) => {
    const page = findPageById(state.activePageId || '', state.pages);
    if (!page) return;

    const newBlock: Block = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      content: type === 'image' ? 'https://picsum.photos/800/400' : 'New block content...',
      width: 100
    };

    updateActivePage({ blocks: [...page.blocks, newBlock] });
  };

  const updateBlock = (blockId: string, updates: Partial<Block>) => {
    const page = findPageById(state.activePageId || '', state.pages);
    if (!page) return;

    const newBlocks = page.blocks.map(b => b.id === blockId ? { ...b, ...updates } : b);
    updateActivePage({ blocks: newBlocks });
  };

  const deleteBlock = (blockId: string) => {
    const page = findPageById(state.activePageId || '', state.pages);
    if (!page) return;

    const newBlocks = page.blocks.filter(b => b.id !== blockId);
    updateActivePage({ blocks: newBlocks });
  };

  const activePage = findPageById(state.activePageId || '', state.pages);

  const handleAISuggestion = async () => {
    if (!activePage) return;
    setIsGenerating(true);
    const content = await generatePageContent(activePage.title);
    addBlock('text');
    // Since addBlock updates state asynchronously, we update the last block manually here for the demo flow
    // In a real app we'd use a more robust state update pattern
    const newBlock: Block = {
        id: Math.random().toString(36).substr(2, 9),
        type: 'text',
        content,
        width: 100
    };
    updateActivePage({ blocks: [...activePage.blocks, newBlock] });
    setIsGenerating(false);
  };

  const renderSidebarItem = (page: Page, depth: number = 0) => {
    const isActive = state.activePageId === page.id;
    return (
      <div key={page.id} className="flex flex-col">
        <div 
          className={`group flex items-center justify-between px-3 py-2 cursor-pointer transition-colors rounded-md ${
            isActive ? 'bg-indigo-50 text-indigo-700' : 'hover:bg-slate-100 text-slate-600'
          }`}
          style={{ paddingLeft: `${depth * 16 + 12}px` }}
          onClick={() => setState(prev => ({ ...prev, activePageId: page.id }))}
        >
          <div className="flex items-center gap-2 overflow-hidden">
            <Layout size={16} className={isActive ? 'text-indigo-600' : 'text-slate-400'} />
            <span className="truncate text-sm font-medium">{page.title}</span>
          </div>
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button 
              onClick={(e) => { e.stopPropagation(); createPage(page.id); }}
              className="p-1 hover:bg-slate-200 rounded text-slate-500"
              title="Add sub-page"
            >
              <Plus size={14} />
            </button>
            <button 
              onClick={(e) => { e.stopPropagation(); deletePage(page.id); }}
              className="p-1 hover:bg-red-100 hover:text-red-600 rounded text-slate-500"
              title="Delete page"
            >
              <Trash2 size={14} />
            </button>
          </div>
        </div>
        {page.subPages.length > 0 && (
          <div className="mt-1">
            {page.subPages.map(sub => renderSidebarItem(sub, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  if (isNameModalOpen) {
    return (
      <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full border border-slate-200">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-indigo-600 rounded-xl text-white">
              <Layers size={24} />
            </div>
            <h2 className="text-2xl font-bold text-slate-800">OmniBuilder</h2>
          </div>
          <p className="text-slate-500 mb-6">Welcome! To get started, please enter your workspace name.</p>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Username or Project Name</label>
              <input 
                autoFocus
                type="text" 
                value={tempUserName}
                onChange={(e) => setTempUserName(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSetUserName()}
                placeholder="e.g. My Portfolio"
                className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
              />
            </div>
            <button 
              onClick={handleSetUserName}
              disabled={!tempUserName.trim()}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg font-bold transition-all shadow-lg shadow-indigo-200 flex items-center justify-center gap-2"
            >
              Start Creating <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside 
        className={`${
          state.isSidebarOpen ? 'w-64' : 'w-0'
        } bg-white border-r border-slate-200 flex flex-col transition-all duration-300 relative group/sidebar overflow-hidden`}
      >
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-indigo-600 text-lg">
            <Layers size={20} />
            <span className="truncate">OmniBuilder</span>
          </div>
        </div>

        <div className="p-4 overflow-y-auto flex-1 custom-scrollbar">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Workspace</h3>
            <button 
              onClick={() => createPage(null)}
              className="p-1.5 hover:bg-indigo-50 text-indigo-600 rounded-md transition-colors"
            >
              <Plus size={16} />
            </button>
          </div>
          <div className="space-y-1">
            {state.pages.map(p => renderSidebarItem(p))}
          </div>
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs">
              {state.userName.charAt(0).toUpperCase()}
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-semibold text-slate-700 truncate">{state.userName}</p>
              <p className="text-xs text-slate-400">Personal Plan</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Toggle Sidebar Button */}
      <button 
        onClick={() => setState(prev => ({ ...prev, isSidebarOpen: !prev.isSidebarOpen }))}
        className="fixed bottom-6 left-6 z-40 p-2 bg-white shadow-xl border border-slate-200 rounded-full text-slate-600 hover:text-indigo-600 transition-all hover:scale-110 active:scale-95"
      >
        {state.isSidebarOpen ? <PanelLeftClose size={20} /> : <PanelLeftOpen size={20} />}
      </button>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-50/30 overflow-hidden relative">
        {activePage ? (
          <>
            {/* Header / Toolbar */}
            <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
              <div className="flex items-center gap-4 flex-1">
                <input 
                  type="text" 
                  value={activePage.title}
                  onChange={(e) => updateActivePage({ title: e.target.value })}
                  className="bg-transparent text-xl font-bold text-slate-800 outline-none focus:ring-b-2 focus:ring-indigo-200 w-full max-w-md"
                />
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={handleAISuggestion}
                  disabled={isGenerating}
                  className="flex items-center gap-2 px-4 py-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 disabled:opacity-50 rounded-lg font-medium text-sm transition-all"
                >
                  <Sparkles size={16} className={isGenerating ? 'animate-pulse' : ''} />
                  {isGenerating ? 'Generating...' : 'AI Suggest'}
                </button>
                <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition-all">
                  <Save size={20} />
                </button>
              </div>
            </header>

            {/* Canvas */}
            <div className="flex-1 overflow-y-auto p-12 custom-scrollbar">
              <div className="max-w-4xl mx-auto space-y-8 pb-32">
                {activePage.blocks.length === 0 && (
                  <div className="border-2 border-dashed border-slate-200 rounded-2xl p-20 flex flex-col items-center justify-center text-slate-400 space-y-4">
                    <div className="p-4 bg-slate-100 rounded-full">
                      <Layout size={40} />
                    </div>
                    <p className="text-center">Your page is empty. Start adding some blocks below!</p>
                  </div>
                )}

                {activePage.blocks.map(block => (
                  <div 
                    key={block.id} 
                    className="relative group block-hover mx-auto transition-all"
                    style={{ width: `${block.width}%` }}
                  >
                    {/* Block Controls */}
                    <div className="block-controls absolute -left-12 top-0 bottom-0 flex flex-col items-center justify-center gap-2 opacity-0 transition-opacity">
                      <div className="bg-white shadow-lg border border-slate-200 rounded-lg p-1 space-y-1">
                        <button 
                          onClick={() => updateBlock(block.id, { width: Math.max(10, block.width - 10) })}
                          className="p-1 hover:bg-slate-100 text-slate-500 rounded" title="Smaller Width"
                        >
                          <Minus size={14} />
                        </button>
                        <button 
                          onClick={() => updateBlock(block.id, { width: Math.min(100, block.width + 10) })}
                          className="p-1 hover:bg-slate-100 text-slate-500 rounded" title="Larger Width"
                        >
                          <Plus size={14} />
                        </button>
                        <div className="border-t border-slate-100 my-1" />
                        <button 
                          onClick={() => deleteBlock(block.id)}
                          className="p-1 hover:bg-red-50 text-red-500 rounded" title="Delete Block"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>

                    {/* Rendering different block types */}
                    {block.type === 'heading' && (
                      <input 
                        type="text" 
                        value={block.content}
                        onChange={(e) => updateBlock(block.id, { content: e.target.value })}
                        className="w-full text-4xl font-extrabold text-slate-900 bg-transparent outline-none placeholder-slate-300"
                        placeholder="Page Heading..."
                      />
                    )}

                    {block.type === 'text' && (
                      <textarea 
                        value={block.content}
                        onChange={(e) => updateBlock(block.id, { content: e.target.value })}
                        rows={Math.max(2, block.content.split('\n').length)}
                        className="w-full text-lg text-slate-600 bg-transparent outline-none resize-none placeholder-slate-300 leading-relaxed"
                        placeholder="Enter your text here..."
                      />
                    )}

                    {block.type === 'image' && (
                      <div className="space-y-3">
                        <div className="relative rounded-2xl overflow-hidden shadow-xl ring-1 ring-slate-200 group/img">
                          <img src={block.content} alt="Block" className="w-full h-auto" />
                          <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center gap-3">
                            <button 
                              onClick={() => {
                                const url = prompt('Enter image URL:', block.content);
                                if (url) updateBlock(block.id, { content: url });
                              }}
                              className="px-4 py-2 bg-white rounded-lg text-sm font-bold text-slate-900 shadow-xl"
                            >
                              Change Image URL
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {block.type === 'divider' && (
                      <div className="py-4">
                        <div className="h-px bg-slate-200 w-full" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions Footer Bar */}
            <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-30">
              <div className="bg-slate-900/90 backdrop-blur-md rounded-2xl shadow-2xl p-2 flex items-center gap-2 border border-slate-700/50">
                <button 
                  onClick={() => addBlock('heading')}
                  className="flex items-center gap-2 px-4 py-2.5 text-slate-200 hover:bg-white/10 rounded-xl transition-all font-medium text-sm"
                >
                  <Type size={18} /> Heading
                </button>
                <button 
                  onClick={() => addBlock('text')}
                  className="flex items-center gap-2 px-4 py-2.5 text-slate-200 hover:bg-white/10 rounded-xl transition-all font-medium text-sm"
                >
                  <FileText size={18} /> Paragraph
                </button>
                <button 
                  onClick={() => addBlock('image')}
                  className="flex items-center gap-2 px-4 py-2.5 text-slate-200 hover:bg-white/10 rounded-xl transition-all font-medium text-sm"
                >
                  <ImageIcon size={18} /> Image
                </button>
                <div className="w-px h-6 bg-slate-700 mx-1" />
                <button 
                  onClick={() => addBlock('divider')}
                  className="flex items-center gap-2 px-4 py-2.5 text-slate-200 hover:bg-white/10 rounded-xl transition-all font-medium text-sm"
                >
                  <Minus size={18} /> Divider
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50">
            <div className="p-6 bg-white rounded-3xl shadow-xl border border-slate-100 max-w-sm">
              <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Layout size={32} />
              </div>
              <h2 className="text-xl font-bold text-slate-800 mb-2">No Active Page</h2>
              <p className="text-slate-500 mb-6">Select a page from the sidebar or create a new one to start building.</p>
              <button 
                onClick={() => createPage(null)}
                className="w-full py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
              >
                <Plus size={20} /> Create New Page
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
