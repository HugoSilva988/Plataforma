
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generatePageContent = async (title: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate a structured text content for a professional webpage titled "${title}". 
      Keep it engaging and professional. Output only the content text.`,
    });
    return response.text || "No content generated.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error generating AI content.";
  }
};
